FinPilot AI — Financial Survival Copilot
Md. Meherab Hossain Talukder — Solo Participant

Play FinPilot_AI_Demo_1080p.mp4. Runtime approximately 2:53.
English neural narration and burned-in captions are included.
The MP3, SRT and exact narration are supplied separately for editing.
Public footage uses the actual synthetic demo. The private AI scene is
a labeled saved verified Groq response, not a new live inference.
AI narration is not the creator's voice. No YouTube upload has been made.
Preview before publishing, then upload the MP4 to your own YouTube account
if you want to provide a YouTube link on Devpost.
