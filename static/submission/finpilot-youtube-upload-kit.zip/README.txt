FinPilot AI — YouTube Upload Kit

1. Upload FinPilot_AI_Demo_1080p.mp4 in YouTube Studio.
2. Copy the complete contents of YouTube_Title.txt and YouTube_Description.txt
   into their corresponding fields. Copy YouTube_Tags.txt into Tags.
3. Use finpilot-youtube-thumbnail.png as the custom thumbnail.
4. Video language: English. Category: Science & Technology.
5. This general-audience finance demo is not made for kids.
6. Optional: add the timed SRT; visible captions are already in the MP4.
7. Choose Unlisted for link sharing with judges, or Public for public access.
   Do not choose Private if judges need access. Complete required disclosures
   truthfully; the description identifies AI narration and synthetic sources.
8. Preview, finish uploading, copy the actual YouTube watch URL and paste it
   into Devpost's Product Demo YouTube Link field.

Created by Md. Meherab Hossain Talukder — Solo Participant.
This kit has not uploaded anything to YouTube or submitted to Devpost.
